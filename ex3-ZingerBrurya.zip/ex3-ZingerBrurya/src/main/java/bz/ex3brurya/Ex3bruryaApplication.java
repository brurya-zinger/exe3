package bz.ex3brurya;

import bz.ex3brurya.bean.Read;
import bz.ex3brurya.bean.State;
import bz.ex3brurya.bean.UserLogin;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.web.context.WebApplicationContext;

@SpringBootApplication
public class Ex3bruryaApplication {

    @Bean
    @Scope(value = WebApplicationContext.SCOPE_SESSION, proxyMode = ScopedProxyMode.TARGET_CLASS)
    public State checkState () {

        return new State();
    }
    @Bean
    public Read reader () {

        return new Read();
    }
    @Bean
    public UserLogin userLog()
    {
        return new UserLogin();

    }
    public static void main(String[] args) {
        SpringApplication.run(Ex3bruryaApplication.class, args);
    }

}
