package bz.ex3brurya.repo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import java.net.URL;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
  @NotBlank(message = "Name is mandatory")
    private String userName;




    private int mone;
    private String url;
    public User()
    {

    }

    public User(String userName ) {
        this.userName = userName;
        int x=1;
        this.mone =x;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setMone(int mone)
    {
        url=" https://github.com/"+userName;
        this.mone = mone;
    }

    public String getUserName() {
        return userName;
    }

    public int getMone() {
        return mone;
    }

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", userName=" + userName + ", mone=" + mone + '}';
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrl() {
        return url;
    }
}

