package bz.ex3brurya.bean;

import org.springframework.stereotype.Component;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Component
public class UserLogin implements Serializable
{
    @NotBlank(message = "Name is mandatory")
    private String name1;
   @NotBlank(message = "password is mandatory")
    private String password;
    public UserLogin(){}

    public String getName() {
        return name1;
    }

    public void setName(String name) {
        this.name1 = name;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }
}
