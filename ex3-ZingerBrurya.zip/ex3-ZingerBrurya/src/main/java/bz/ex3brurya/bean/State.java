package bz.ex3brurya.bean;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/** this class is bean in session it will let us know bout the session state
 */
@Component
public class State implements Serializable
{
    private boolean state;
    public State()
    {
        state=false;

    }

    public boolean getState() {
        return state;

    }
    public void setState(boolean f)
    {
        this.state=f;
    }
}
