package bz.ex3brurya.bean;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.stereotype.Component;

import java.util.ArrayList;


/***
 * this class is bean
 * Contains the variables I need to search user  from the gitub
 */
@Component
public class Read implements Serializable
{

private BufferedReader in;
    //    private InputStream input;
    private URL url;
    private String name;
    public Read(){}
    public Read(String name) throws IOException, MalformedURLException
    {
        this.name=name;

        url=new URL("https://api.github.com/users/"+name);
        System.out.println("myurl "+url);
        in=new BufferedReader( new InputStreamReader(url.openStream()));
    }
    public JsonObject  readUrl()  throws IOException
    {

       String result="";
        String inputLine;
        while ((inputLine = in.readLine()) != null)
        {
//
            result+=inputLine;
//            result.add((String) inputLine);

        }

        JsonObject convertedObject = new Gson().fromJson(result, JsonObject.class);
        in.close();
        return convertedObject;




    }

    public void setUrl(URL url) {
        this.url = url;
    }

    public void setName(String name) throws IOException, MalformedURLException
    {
        this.name = name;
        url=new URL("https://api.github.com/users/"+name);
        in=new BufferedReader( new InputStreamReader(url.openStream()));

    }

    public URL getUrl() {
        return url;
    }

    public String getName()
    {

        return name;
    }
}
