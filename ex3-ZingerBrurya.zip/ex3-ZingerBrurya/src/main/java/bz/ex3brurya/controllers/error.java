package bz.ex3brurya.controllers;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * this controller catch all the error exception and presents a html view
 */
@Controller
public class error  implements ErrorController {

    @RequestMapping("/error")
    public String handleError()
    {
        System.out.println("in error");
        return "view_error";
    }

    @Override
    public String getErrorPath()
    {
        return "/error";
    }
}


