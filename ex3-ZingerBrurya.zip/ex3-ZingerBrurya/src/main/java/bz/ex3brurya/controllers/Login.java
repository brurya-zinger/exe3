package bz.ex3brurya.controllers;

import bz.ex3brurya.bean.Read;
import bz.ex3brurya.bean.State;
import bz.ex3brurya.bean.UserLogin;
import bz.ex3brurya.repo.User;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * this controller handle the login process
 */
@Controller
public class Login {
    @Resource(name = "userLog")
    private UserLogin user_login;

    @Resource(name = "checkState")
    private State state;
    @Value("${demo.userName}")
    private String userName;
    @Value("${demo.password}")
    private String password;

    /**
     * landing page
     * If a user already sign in return menu page
     * else return login
     * @return
     */
    @GetMapping("/")
    public String main() {
        if(state.getState())
        {
            return "o";
        }

        return "login";
    }

//    @PostMapping("/signIn")
//    public String login(@Valid UserLogin user, BindingResult result, Model model)
//    {
//        System.out.println("in /signIn");
//        if (result.hasErrors())
//        {
//            return "login";
//        }
//        if((userName.equals(user.getName()))&& (password.equals(user.getPassword())))
//        {
//            System.out.println("in login eqaul");
////            state.setState(true);
//            return "o";
//        }
//        model.addAttribute("errorMesg","user not valid");
//        return "login";
//
//    }

    /**
     *
     * @param name the login name the user type
     * @param pass the password name the user type
     * @param model login
     * @return login or menu page if not correct
     */
    @PostMapping("/signIn")
    public String login(@RequestParam(name = "yourname", required = false, defaultValue = "missing") String name,
                        @RequestParam(name = "password", required = false, defaultValue = "missing") String pass, Model model) {


        if (name.equals("missing") || (pass.equals("missing"))) {
            model.addAttribute("errorMesg", "missing details");
            return "login";
        }

        if ((userName.equals(name)) && (password.equals(pass))) {
            state.setState(true);
            return "o";

        } else {
            model.addAttribute("errorMesg", "wrong details");
            return "login";
        }


    }

    /**
     * Handles system logout
     * @param user
     * @param model
     * @param request  for the session
     * @return logout view
     */
    @GetMapping("/logOut")
    public String logOut(User user, Model model, HttpServletRequest request) {
        model.addAttribute("name", userName);
        request.getSession().invalidate();
        return "logOut";
    }

    @GetMapping("/signIn")
    public String getSignIn() {
        return "redirect:/";
    }

}
