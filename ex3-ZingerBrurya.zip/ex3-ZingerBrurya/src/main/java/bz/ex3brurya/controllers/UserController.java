package bz.ex3brurya.controllers;

import bz.ex3brurya.bean.State;
import bz.ex3brurya.repo.User;
import bz.ex3brurya.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.validation.Valid;
import java.util.List;

/**
 * handel user process
 */
@Controller
public class UserController
{

   @Autowired
    private UserRepository repository;

    private UserRepository getRepo()
    {
        return repository;
    }

    /**
     * action from menu page
     * @return tem->view history
     */
    @GetMapping("/temp")
    public String temp()
    {
        return  "temp";
    }

    /**
     * fetch from temp
     * @param model
     * @return json from url
     */
    @GetMapping("/history")
    public  @ResponseBody List<User> view_history(  Model model)
    {

        return getRepo().findFirst10ByOrderByMoneDesc();

    }

    /**
     * delete the history
     * @param model
     * @return temp-> view history
     */
    @GetMapping("/deleteHistory")
    public String delete_history( Model model)
    {
        getRepo().deleteAll();
        List<User> u;
        u= getRepo().findAll();

        model.addAttribute("users",u);
        return "temp";

    }

    /**
     * back to menu
     * @param model
     * @return menu page
     */
    @GetMapping("/back_home")
public String back_home(  Model model)
{


    return "o";
}

    /**
     * herf from menu page
     * @param user
     * @return search view
     */
    @GetMapping("/search")
    public String getSignIn( User user)
    {
        return "search";
    }


    /**
     * submit in search from
     * @param user the user we look for
     * @param result
     * @param model search
     * @return "forward:read";
     */
    @PostMapping("/search")
    public String search( @Valid User user, BindingResult result,Model model)

    {

        if (result.hasErrors()) {
            return "search";
        }


        List<User> u;
        u=getRepo().findByUserName(user.getUserName());
        if(u.size()!=0)
        {

            User y=u.get(0);
            y.setMone(y.getMone() +1);
            getRepo().save(y);
        }
        else
        {

            user.setMone(1);
            getRepo().save(user);
        }

        return "forward:read";
    }



}
