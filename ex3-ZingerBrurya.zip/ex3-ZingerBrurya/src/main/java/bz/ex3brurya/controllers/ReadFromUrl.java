package bz.ex3brurya.controllers;

import bz.ex3brurya.bean.Read;
import bz.ex3brurya.repo.User;
import com.google.gson.JsonObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.annotation.Resource;
import java.util.ArrayList;

/**
 * this controller read from url
 */
@Controller
public class ReadFromUrl
{
    @Resource(name = "reader")
    private Read bufer_reder;


    @GetMapping("/read")
public String getRead(User u)
{
    return "redirect:/";
}

    /**
     * "forward from search
     * @param u the search user bean
     * @param model search
     * @return search view
     */
    @PostMapping("/read")
    public String getDetails(User u, Model model)
    {
        try
        {


        bufer_reder.setName(u.getUserName());
            JsonObject result=bufer_reder.readUrl();

            if(result.get("followers").getAsString().equals("0"))
            {
                model.addAttribute("errorMesg","no followers");


            }

            else
            {


                model.addAttribute("followers", result.get("followers").getAsString());
            }
            model.addAttribute("login", result.get("login").getAsString());




        }
        catch (Exception e)
        {
            model.addAttribute("errorMesg","No user exists");


        }
        return "search";
    }
}
