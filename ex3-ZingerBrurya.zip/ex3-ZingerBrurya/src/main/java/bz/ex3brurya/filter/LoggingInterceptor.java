package bz.ex3brurya.filter;

import bz.ex3brurya.bean.State;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoggingInterceptor implements HandlerInterceptor {

    private State state;

    public LoggingInterceptor(State state) {
        this.state = state;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {

        if (state.getState())
            return true;
        else
            response.sendRedirect("/");
        return false;
       // return true;
    }

}
