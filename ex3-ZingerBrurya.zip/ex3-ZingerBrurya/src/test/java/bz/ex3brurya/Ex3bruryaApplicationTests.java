package bz.ex3brurya;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex3bruryaApplicationTests {

    @Test
    void contextLoads() {
    }

}
